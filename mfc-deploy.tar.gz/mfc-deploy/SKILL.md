---
name: mfc-deploy
description: 远端部署 mae-flow-cloud。支持 --env test(默认)/prod/all 选择部署环境。拉最新代码、同步到远端服务器、npm ci、web build、重启服务、验证。适用于"部署""上线""升级远端"等场景。
---

# MFC 远端部署 Skill

## 部署环境选择

通过 `--env` 参数指定部署目标：

| 参数 | 目标 | 说明 |
|------|------|------|
| `--env test` | 测试环境 | **默认值**，只重启测试三件套 |
| `--env prod` | 生产环境 | 只重启生产三件套 |
| `--env all` | 两个环境 | 先停全部→rsync→npm ci→web build→重启全部 |

⚠️ **两套环境各自独立的 repo**：rsync 和 npm ci / web build 需分别执行。
测试环境不管咋更新代码重启服务，不影响生产环境。

## 两套环境概览

| | 生产 (prod) | 测试 (test) |
|---|---|---|
| **serve 端口** | 8787 | 8788 |
| **adapter 端口** | 8790 | 8792 |
| **luban-bridge 端口** | 8791 | 8793 |
| **data 目录** | `/data/mae-flow-cloud/data` | `/data/mae-flow-cloud-test/data` |
| **cache 目录** | `/data/mae-flow-cloud/cache` | `/data/mae-flow-cloud-test/cache` |
| **logs 目录** | `/data/mae-flow-cloud/logs` | `/data/mae-flow-cloud-test/logs` |
| **配置目录** | `/etc/mae-flow-cloud/` | `/etc/mae-flow-cloud-test/` |
| **容器 CPU** | 16 核 | 4 核 |
| **容器内存** | 24g | 8g |
| **并发任务** | 10 | 2 |
| **build-slots** | 4 | 1 |
| **容器指纹** | `662e8131...` | `db35f0b5...` |
| **systemd 服务** | `mae-flow-serve` / `adapter` / `luban-bridge` | `mae-flow-serve-test` / `adapter-test` / `luban-bridge-test` |

**完全独立的配置**（各自副本，内容相同，互不影响）：
- `models.json` — 各自副本（同一个 GLM-5.1-NN 网关）
- `codehub-token` / `mcp-token` / `luban-plugin.token` / `luban-token` — 各自副本
- Maven settings — 各自副本
- `repo/` — **各自独立**（独立的 node_modules、web/dist、__pycache__）

**只读/不可变共享**（不影响隔离）：
- `isolate-image` — 同一个 Docker 镜像（只读）
- `isolate-user` — 同一个 OS uid 10001（不可变）
- Node.js — 同一个 /usr/local/node-v24（只读）
- Docker daemon — 共用（容器按 dataDir 指纹隔离，互不干扰）
- `mcp-token` 刷新 — crontab 同时刷新两份副本

## 远端目录结构（代码与数据物理隔离）

```
/data/mae-flow-cloud/               ← 生产
├── repo/          ← 生产代码（rsync 目标，随便 --delete）
│   ├── src/
│   ├── kernel/
│   ├── web/dist/
│   ├── package.json
│   └── node_modules/
├── data/          ← 运行时数据（rsync 绝不碰）
│   ├── auth.json
│   ├── task-*/
│   └── .deploy-backup/
├── cache/         ← 构建缓存（rsync 绝不碰）
└── logs/          ← 日志（rsync 绝不碰）

/data/mae-flow-cloud-test/          ← 测试（完全独立）
├── repo/          ← 测试代码（rsync 目标，独立的 node_modules/web/dist）
│   ├── src/
│   ├── kernel/
│   ├── web/dist/
│   ├── package.json
│   └── node_modules/
├── data/          ← 运行时数据（独立）
├── cache/         ← 构建缓存（独立）
└── logs/          ← 日志（独立）

/etc/mae-flow-cloud/                ← 生产配置、脚本、密钥（rsync 绝不碰）
/etc/mae-flow-cloud-test/           ← 测试配置、脚本、密钥（独立副本，rsync 绝不碰）
```

**核心原则**：
- rsync 只动 `repo/`，`data/`、`cache/`、`logs/`、配置目录全在外面
- **生产与测试各自独立的 repo**：npm ci、web build、__pycache__ 互不影响
- 测试环境不管咋更新代码重启服务，不影响生产环境

## 远端环境速查

| 项目 | 值 |
|------|-----|
| 服务器 | `7.242.244.33` (eth0=192.168.7.101) |
| SSH | `sshpass -p 'Changeme_456' ssh -o StrictHostKeyChecking=no root@7.242.244.33` |
| 生产代码路径 | `/data/mae-flow-cloud/repo` |
| 测试代码路径 | `/data/mae-flow-cloud-test/repo` |
| Node 24 | `/usr/local/node-v24.19.0-linux-x64/bin/node` |

## systemd 服务一览

| 服务 | 端口 | 环境 | --config |
|------|------|------|----------|
| `mae-flow-serve` | 8787 | prod | `/etc/mae-flow-cloud/serve.json` |
| `mae-flow-adapter` | 8790 | prod | `/etc/mae-flow-cloud/adapter.json` |
| `mae-flow-luban-bridge` | 8791 | prod | ( WorkingDirectory `/etc/mae-flow-cloud` ) |
| `mae-flow-serve-test` | 8788 | test | `/etc/mae-flow-cloud-test/serve.json` |
| `mae-flow-adapter-test` | 8792 | test | `/etc/mae-flow-cloud-test/adapter.json` |
| `mae-flow-luban-bridge-test` | 8793 | test | ( `--port 8793` ) |

## 重启恢复要点（docs/restart-recovery.md 摘要）

每次部署本质是"停服→换代码→起服"，起服时 `recover()` 自动恢复任务。
以下是需要人工注意的边界情况：

| 阶段/状态 | 重启后行为 | 人工动作 |
|---|---|---|
| queued / running(编码中) | 无感：重新入队，以内核 current 为锚续跑 | 无 |
| waiting_for_human | 无感：原地继续等 | 无 |
| prepush 验证中 | 无感：僵尸轮自动翻新一轮 | 无 |
| verifying + 流水线轮询中 | 无感：按 delivery.sha 续轮，新预算 | 无 |
| verifying + 轮询预算耗尽 | 无感：续轮不重触发（修前会白烧流水线） | 无 |
| verifying + 已停摆(stalled) | 保持停摆 | 页面点「重跑」 |
| await_merge | 无感：watchMerge 重新武装 | 无 |
| paused / pausing | 安全落 paused，不擅自续跑 | 人工恢复 |
| 问题流会话(issue) | 标记「服务重启打断」，现场保留 | 用户发一句话即续 |
| 修复环 | 无感：轮数与同 SHA 刹车都在派单前落盘 | 无 |
| **在途/失败通知** | **重启即丢，不重发** | 人工扫等待中任务，私下知会责任人 |
| 登录会话 | 已落盘，重启不踢人 | 无 |

## 标准部署流程

### Step 1: 本地拉代码 & 验证

```bash
cd /home/l00899311/dev/mae-flow-cloud
git pull --ff-only
npm run typecheck          # 零构建≠不查类型
cd web && npx vite build   # 本地验证 web 能构建
```

**失败则停**，不部署有 typecheck 错误的代码。

### Step 2: 远端停服务 & 备份

⚠️ **停服顺序**：先 SIGTERM（不是 kill -9），然后检查 detached git push，最后备份 auth.json。

按 `--env` 决定停哪组服务：

| --env | 停的服务 | 备份的 auth.json |
|-------|---------|-----------------|
| test | `mae-flow-serve-test mae-flow-adapter-test mae-flow-luban-bridge-test` | `/data/mae-flow-cloud-test/data/auth.json` |
| prod | `mae-flow-serve mae-flow-adapter mae-flow-luban-bridge` | `/data/mae-flow-cloud/data/auth.json` |
| all | 全部 6 个 | 两份都备份 |

```bash
sshpass -p 'Changeme_456' ssh -o StrictHostKeyChecking=no root@7.242.244.33 bash << 'OUTER'
# 2a. SIGTERM 停指定环境的服务
# test:  systemctl stop mae-flow-serve-test mae-flow-adapter-test mae-flow-luban-bridge-test
# prod:  systemctl stop mae-flow-serve mae-flow-adapter mae-flow-luban-bridge
# all:   systemctl stop mae-flow-serve mae-flow-adapter mae-flow-luban-bridge \
#          mae-flow-serve-test mae-flow-adapter-test mae-flow-luban-bridge-test

# 2b. 检查 detached git push（推送进程能活过服务停掉）
GIT_PUSH_COUNT=$(ps -eo pid,ppid,etime,command | grep -c "[g]it push" || true)
if [ "$GIT_PUSH_COUNT" -gt 0 ]; then
    echo "⚠ 检测到 $GIT_PUSH_COUNT 个 git push 进程仍在跑，等待完成（≤5分钟预算）…"
    ps -eo pid,ppid,etime,command | grep "[g]it push"
    for i in $(seq 1 30); do
        sleep 10
        GIT_PUSH_COUNT=$(ps -eo pid,ppid,etime,command | grep -c "[g]it push" || true)
        if [ "$GIT_PUSH_COUNT" -eq 0 ]; then
            echo "git push 已全部完成"
            break
        fi
        if [ "$i" -eq 30 ]; then
            echo "⚠ 等待超时（5分钟），仍有 $GIT_PUSH_COUNT 个 git push，继续部署请确认风险"
        fi
    done
else
    echo "无残留 git push 进程"
fi

# 2c. 备份 auth.json（按环境备份对应的 data 目录）
# test: /data/mae-flow-cloud-test/data/auth.json
# prod: /data/mae-flow-cloud/data/auth.json
# all:  两份都备份
OUTER
```

### Step 3: rsync 代码到远端

按 `--env` 决定同步到哪个 repo（两套独立，需分别同步）：

| --env | rsync 目标 |
|-------|-----------|
| test | `/data/mae-flow-cloud-test/repo/` |
| prod | `/data/mae-flow-cloud/repo/` |
| all | 先 prod 再 test |

```bash
# 以 test 为例
rsync -az \
  -e "sshpass -p 'Changeme_456' ssh -o StrictHostKeyChecking=no" \
  --delete \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='.pilot' \
  --exclude='.local' \
  /home/l00899311/dev/mae-flow-cloud/ \
  root@7.242.244.33:/data/mae-flow-cloud-test/repo/
```

### Step 4: 校验 auth.json 完整性

按 `--env` 校验对应环境的 auth.json：

| --env | 校验路径 |
|-------|---------|
| test | `/data/mae-flow-cloud-test/data/auth.json` |
| prod | `/data/mae-flow-cloud/data/auth.json` |
| all | 两份都校验 |

```bash
# 以 test 为例
sshpass -p 'Changeme_456' ssh -o StrictHostKeyChecking=no root@7.242.244.33 bash << 'OUTER'
AUTH_FILE="/data/mae-flow-cloud-test/data/auth.json"
BACKUP_DIR="/data/mae-flow-cloud-test/data/.deploy-backup"
mkdir -p "$BACKUP_DIR"
USER_COUNT=$(python3 -c "import json; print(len(json.load(open('$AUTH_FILE')).get('users',[])))" 2>/dev/null || echo "0")
if [ "$USER_COUNT" -le 1 ]; then
    LATEST=$(ls -t "$BACKUP_DIR"/auth.json.* 2>/dev/null | head -1)
    if [ -n "$LATEST" ]; then
        cp -a "$LATEST" "$AUTH_FILE"
        echo "已从备份恢复 auth.json"
    fi
fi
OUTER
```

### Step 5: 远端清理 & 安装

按 `--env` 在对应 repo 里执行 npm ci + web build（两套独立，需分别执行）：

| --env | npm ci + build 目录 |
|-------|-------------------|
| test | `/data/mae-flow-cloud-test/repo` |
| prod | `/data/mae-flow-cloud/repo` |
| all | 先 prod 再 test |

```bash
# 以 test 为例
sshpass -p 'Changeme_456' ssh -o StrictHostKeyChecking=no root@7.242.244.33 bash << 'OUTER'
set -e

# 清内核 __pycache__
find /data/mae-flow-cloud-test/repo/kernel -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true

# npm ci
cd /data/mae-flow-cloud-test/repo
npm ci

# web build（必须用 node24）
export PATH=/usr/local/node-v24.19.0-linux-x64/bin:$PATH
cd web
npx vite build

# 确保日志目录存在
mkdir -p /data/mae-flow-cloud-test/logs
touch /data/mae-flow-cloud-test/logs/serve.log \
      /data/mae-flow-cloud-test/logs/adapter.log \
      /data/mae-flow-cloud-test/logs/luban-bridge.log
OUTER
```

### Step 6: 重启服务 & 启动日志检查

按 `--env` 重启对应服务：

| --env | 启动的服务 | 检查的端口 |
|-------|-----------|-----------|
| test | `mae-flow-serve-test` → `adapter-test` → `luban-bridge-test` | 8788 / 8792 / 8793 |
| prod | `mae-flow-serve` → `adapter` → `luban-bridge` | 8787 / 8790 / 8791 |
| all | 先 prod 三件套，再 test 三件套 | 全部 6 个 |

```bash
# 以 test 为例
sshpass -p 'Changeme_456' ssh -o StrictHostKeyChecking=no root@7.242.244.33 bash << 'OUTER'
set -e

systemctl daemon-reload
systemctl start mae-flow-serve-test
sleep 4
systemctl start mae-flow-adapter-test
sleep 2
systemctl start mae-flow-luban-bridge-test
sleep 2

# 检查服务状态
systemctl is-active mae-flow-serve-test mae-flow-adapter-test mae-flow-luban-bridge-test
curl -s -o /dev/null -w "serve(8788): %{http_code}\n" http://localhost:8788/
curl -s -o /dev/null -w "adapter(8792): %{http_code}\n" http://localhost:8792/health

# auth.json 完整性
python3 -c "
import json
d=json.load(open('/data/mae-flow-cloud-test/data/auth.json'))
users=[u['username'] for u in d.get('users',[])]
print(f'auth: {len(users)} 个账号')
"

# 启动日志关键指标
echo "=== 启动日志 ==="
journalctl -u mae-flow-serve-test --since "2 min ago" --no-pager \
  | grep -E "已清理遗留|恢复任务|实例锁|ownership|拒绝启动" || echo "(无异常关键词)"

# 坏档扫描
echo "=== 坏档扫描 ==="
BAD=0
for f in /data/mae-flow-cloud-test/data/task-*/task.json; do
    if ! python3 -m json.tool "$f" >/dev/null 2>&1; then
        echo "⚠ 坏档: $f"
        BAD=$((BAD+1))
    fi
done
for f in /data/mae-flow-cloud-test/data/task-*/waiting.json; do
    if [ -f "$f" ] && ! python3 -m json.tool "$f" >/dev/null 2>&1; then
        echo "⚠ 坏档: $f"
        BAD=$((BAD+1))
    fi
done
if [ "$BAD" -eq 0 ]; then echo "全部 task.json / waiting.json 完整"; fi

# 旧 issue 容器（只列出、不自动删）
echo "=== 旧 issue 容器 ==="
ORPHANS=$(docker ps -a \
  --filter label=com.mae-flow-cloud.role=issue \
  --format '{{.Names}}\t{{.Status}}\t{{.Label "com.mae-flow-cloud.instance"}}' \
  | awk -F'\t' '$3==""')
if [ -n "$ORPHANS" ]; then
    echo "⚠ 发现无 instance 标签的旧 issue 容器:"
    echo "$ORPHANS" | sed 's/^/  /'
    echo "⚠ 请逐个确认：Up=活会话(等用户发完话再清)；Exited=安全可删(docker rm <名字>)"
else
    echo "无旧 issue 容器残留"
fi
OUTER
```

### Step 7: 部署公告

部署后请发公告（小鲁班/IM）：

> 1. 浏览器请强制刷新（Cmd/Ctrl+Shift+R）——老页签的懒加载 chunk 换代码后会 404
> 2. 登录会话已落盘，重启不会踢回登录页
> 3. 如有等待审批的任务，请检查通知是否在部署期间丢失——页面待办清单为准

**部署测试环境时**，公告可简化为"测试环境已更新，请刷新浏览器"。

## 常见坑 & 排查

### 🔴 旧路径残留

**症状**：服务启动失败或跑旧代码。

**修**：检查 systemd 和 serve.json/serve-test.json 里的路径。

### 🔴 容器 ownership 复验拒绝启动

**症状**：serve 启动后立即退出，日志含"ownership"或"拒绝启动"。

**修**：查看启动日志里的具体容器名和原因；确认是本实例遗留的旧容器后手动 `docker rm -f`；**绝不能跳过复验硬启**。

### 🔴 旧 issue 容器无标签

**症状**：mfc-*-issue-* 容器没有 `com.mae-flow-cloud.instance` 标签。

**修**：用 `--filter label=com.mae-flow-cloud.role=issue` 精确筛选，只看 instance 标签为空的。**必须先看 Status**：`Up`=活会话等用户发完话再清，`Exited`=安全可删。⚠️ **绝不能盲目 `docker rm -f`**。

### systemd 启动失败 status=209

**原因**：日志目录不存在。

**修**：`mkdir -p /data/mae-flow-cloud/logs && touch ...serve.log`（测试环境同理）

### vite build 报 `styleText` 错误

**修**：`export PATH=/usr/local/node-v24.19.0-linux-x64/bin:$PATH`

### 内核 __pycache__ 报 stale bytecode

**修**：`find /data/mae-flow-cloud/repo/kernel -name __pycache__ -type d -exec rm -rf {} +`

### C++ 编译 OOM (cc1plus Killed)

**修**：生产 `"isolate-memory": "24g"`；30 万行 C++ 仓 `make -j16` 峰值需 15G+，8g 必 OOM。

### C++ 编译被 CPU 限流（nr_throttled 涨）

**修**：`"isolate-cpus"` 与实际 CPU 核数匹配。

### prepush 编译超时被杀

**修**：`"prepush-build-timeout-minutes": 75, "prepush-attempt-timeout-minutes": 90`

### 部署后通知丢失

**原因**：在途/失败的通知重启即丢，不重发。

**修**：人工扫等待中的任务，私下知会责任人。

### 🔴 两套环境的 data 目录千万不能搞混

**prod 的 data**：`/data/mae-flow-cloud/data`
**test 的 data**：`/data/mae-flow-cloud-test/data`

serve.json 的 `"data"` 字段决定了实例指纹和容器归属。配错会导致：
- 测试环境的容器被生产清扫杀掉（指纹不匹配）
- 生产数据被测试实例写入（两个实例共写一个 dataDir）

## 一键部署脚本

完整流程用 [deploy.sh](scripts/deploy.sh) 一键执行：

```bash
# 默认部署测试环境
.pi/skills/mfc-deploy/scripts/deploy.sh

# 部署生产环境
.pi/skills/mfc-deploy/scripts/deploy.sh --env prod

# 两个环境都部署
.pi/skills/mfc-deploy/scripts/deploy.sh --env all

# 跳过本地验证
.pi/skills/mfc-deploy/scripts/deploy.sh --env test --skip-local-check
```